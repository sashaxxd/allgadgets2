<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=utzetgio_test',
    'username' => 'utzetgio_trehgor',
    'password' => '522433',
    'charset' => 'utf8',
];
