<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=kostianfio_all-gadjets',
    'username' => '046202554_all-ga',
    'password' => '522433',
    'charset' => 'utf8',
];
