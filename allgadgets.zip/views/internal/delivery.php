<?php
$this->title = 'ДОСТАВКА allgadgets';
?>
<div id="allgadgets_contauer_pop_ostov">
    <div id="contauer_pop_ostov">
        <div class="row">
            <div class="col-1">
            </div>
            <div class="col-2">
                <div id="allgadgets_contauer_content">
                    <div id="contauer_content">
                        <div class="row">
                            <div class="col-1">
                                <hr id="Line1">
                                <div id="allgadgets_Text1">
                                    <span id="allgadgets_uid4"><h2><?=  $model->title;  ?></h2>
                                        <br>
                                         <div class="g_text" style="float: left;">
                                             <?= $model->text; ?>
                                         </div>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-3">
            </div>
        </div>
    </div>
</div>