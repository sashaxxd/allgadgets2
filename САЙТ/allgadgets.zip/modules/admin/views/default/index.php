<div class="admin-default-index">
    <h3>ПРИВЕТ ВИКТОР!  ВЫ ВОШЛИ В ПАНЕЛЬ АДМИНИСТРАТОРА САЙТА</h3>
    <p>
        <?php
$date_today = date("m.d.y");
$today[1] = date("H:i:s");
echo("Текущее время: $today[1] и дата: $date_today .");
?>
    </p>

</div>
